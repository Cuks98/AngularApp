export interface Class{
    id: number,
    name : string
}