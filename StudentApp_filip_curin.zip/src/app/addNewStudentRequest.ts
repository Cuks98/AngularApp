export interface AddNewStudentRequest{
    firstName: string,
    lastName: string,
    dateOfBirth: string,
    jmbag: string,
    ects: number
}